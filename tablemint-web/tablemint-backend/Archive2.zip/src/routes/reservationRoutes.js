const express = require('express');
const router = express.Router();

const rc = require('../../../../../Downloads/tablemint/tablemint-backend/src/controllers/reservationController');
const { protect, restrictTo } = require('../../../../../Downloads/tablemint/tablemint-backend/src/middleware/auth');
const { validate, schemas } = require('../../../../../Downloads/tablemint/tablemint-backend/src/middleware/validate');

router.use(protect);

// ── Customer ──────────────────────────────────────────────────────────────────
router.post('/',          restrictTo('customer'), validate(schemas.createReservationSchema), rc.createReservation);
router.get('/my',         restrictTo('customer'), rc.getMyReservations);
router.patch('/:id/cancel', restrictTo('customer'), rc.cancelReservation);

// ── Admin only ────────────────────────────────────────────────────────────────
router.get('/admin/all',   restrictTo('admin'), rc.getAllReservations);
router.get('/admin/stats', restrictTo('admin'), rc.getReservationStats);

// ── Owner + Captain + Admin: restaurant reservations ─────────────────────────
// 'owner' was missing here — that was the 403 error
router.get(
    '/restaurant/:restaurantId',
    restrictTo('admin', 'owner', 'captain'),
    rc.getRestaurantReservations
);

// ── Owner + Captain + Admin: update reservation status ───────────────────────
router.patch(
    '/:id/status',
    restrictTo('admin', 'owner', 'captain'),
    validate(schemas.updateReservationStatusSchema),
    rc.updateReservationStatus
);

// ── Shared: single reservation (auth checked in controller) ──────────────────
router.get('/:id', rc.getReservation);

module.exports = router;