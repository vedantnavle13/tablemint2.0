import { useState } from "react";
import { useNavigate } from "react-router-dom";

const C = {
    bg:        "#FDFAF6",
    bgSoft:    "#F5F0E8",
    bgCard:    "#FFFFFF",
    border:    "#E8E0D0",
    amber:     "#D4883A",
    amberSoft: "#FBF0E0",
    text:      "#2C2416",
    textMid:   "#6B5B45",
    textMuted: "#A0907A",
    green:     "#4A9B6F",
    red:       "#D05A4A",
};

export default function ForRestaurants() {
    const navigate = useNavigate();
    const [loginType, setLoginType] = useState("owner"); // "owner" or "admin"

    const handleLogin = () => {
        if (loginType === "owner") {
            navigate('/owner/login');
        } else {
            navigate('/admin/login');
        }
    };

    return (
        <div style={{ background: C.bg, minHeight: "100vh", fontFamily: "'DM Sans', sans-serif" }}>
            <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=DM+Sans:wght@400;500;600;700&display=swap');
        * { box-sizing:border-box; margin:0; padding:0; }
        ::-webkit-scrollbar { width:5px; }
        ::-webkit-scrollbar-thumb { background:#D4C4B0; border-radius:3px; }
      `}</style>

            {/* NAVBAR */}
            <nav style={{
                position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
                height: 60, padding: "0 6%",
                display: "flex", alignItems: "center", justifyContent: "space-between",
                background: "rgba(253,250,246,0.96)",
                backdropFilter: "blur(12px)",
                borderBottom: `1px solid ${C.border}`,
            }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }} onClick={() => navigate('/')}>
                    <span style={{ fontSize: 21 }}>🍽️</span>
                    <span style={{
                        fontFamily: "'Playfair Display', serif",
                        fontSize: 20, fontWeight: 700, color: C.text,
                    }}>Table<span style={{ color: C.amber }}>Mint</span></span>
                </div>

                <div style={{ display: "flex", gap: 28 }}>
                    {[
                        {label: "Home", path: "/"},
                        {label: "Explore", path: "/explore"},
                        {label: "How It Works", path: "/#how"},
                        {label: "For Restaurants", path: "/for-restaurants"}
                    ].map(item => (
                        <span key={item.label} style={{
                            color: item.path === "/for-restaurants" ? C.amber : C.textMuted,
                            fontSize: 14, fontWeight: item.path === "/for-restaurants" ? 700 : 500,
                            cursor: "pointer", transition: "color 0.2s",
                        }}
                              onClick={() => navigate(item.path)}
                              onMouseEnter={e => e.target.style.color = C.amber}
                              onMouseLeave={e => e.target.style.color = item.path === "/for-restaurants" ? C.amber : C.textMuted}
                        >{item.label}</span>
                    ))}
                </div>

                <button onClick={() => navigate('/explore')} style={{
                    background: C.amber, border: "none",
                    color: "#fff", fontSize: 14, fontWeight: 600,
                    cursor: "pointer", padding: "8px 20px", borderRadius: 10,
                    fontFamily: "'DM Sans', sans-serif",
                }}>Browse Restaurants</button>
            </nav>

            {/* MAIN CONTENT - TWO COLUMNS */}
            <div style={{ marginTop: 60, display: "grid", gridTemplateColumns: "1fr 420px", minHeight: "calc(100vh - 60px)" }}>

                {/* LEFT SIDE - MARKETING CONTENT (SCROLLABLE) */}
                <div style={{ padding: "60px 6% 80px", overflowY: "auto" }}>

                    {/* HERO SECTION */}
                    <div style={{ marginBottom: 60 }}>
                        <div style={{
                            display: "inline-flex", alignItems: "center", gap: 8,
                            background: C.amberSoft,
                            border: `1px solid ${C.amber}40`,
                            borderRadius: 100, padding: "6px 18px", marginBottom: 24,
                        }}>
                            <span style={{ fontSize: 16 }}>🚀</span>
                            <span style={{
                                color: C.amber, fontSize: 13, fontWeight: 700,
                                letterSpacing: 1, fontFamily: "'DM Sans', sans-serif",
                            }}>PARTNER WITH US</span>
                        </div>

                        <h1 style={{
                            fontFamily: "'Playfair Display', serif",
                            fontSize: "clamp(36px, 5vw, 56px)",
                            fontWeight: 900, color: C.text,
                            lineHeight: 1.15, marginBottom: 20, letterSpacing: -1,
                        }}>
                            Grow Your Restaurant<br />
                            <span style={{ color: C.amber, fontStyle: "italic" }}>Business with TableMint</span>
                        </h1>

                        <p style={{
                            fontSize: 18, color: C.textMid, lineHeight: 1.7,
                            marginBottom: 32, maxWidth: 560,
                        }}>
                            Join 500+ restaurants already maximizing bookings, reducing no-shows, and delighting customers with seamless reservations.
                        </p>

                        {/* HERO IMAGE */}
                        <div style={{
                            width: "100%", height: 400,
                            borderRadius: 20, overflow: "hidden",
                            backgroundImage: "url('https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=1200')",
                            backgroundSize: "cover", backgroundPosition: "center",
                            border: `2px solid ${C.border}`,
                            boxShadow: "0 12px 48px rgba(0,0,0,0.1)",
                        }} />
                    </div>

                    {/* STATS SECTION */}
                    <div style={{
                        display: "grid", gridTemplateColumns: "repeat(4, 1fr)",
                        gap: 20, marginBottom: 60,
                        padding: 32, background: C.bgCard,
                        borderRadius: 16, border: `1px solid ${C.border}`,
                    }}>
                        {[
                            { val: "500+", label: "Restaurants" },
                            { val: "50K+", label: "Happy Diners" },
                            { val: "₹2Cr+", label: "Revenue Generated" },
                            { val: "4.8★", label: "Avg Rating" },
                        ].map(stat => (
                            <div key={stat.label} style={{ textAlign: "center" }}>
                                <div style={{
                                    fontFamily: "'Playfair Display', serif",
                                    fontSize: 32, fontWeight: 700, color: C.amber, marginBottom: 4,
                                }}>{stat.val}</div>
                                <div style={{ fontSize: 13, color: C.textMuted, fontWeight: 500 }}>
                                    {stat.label}
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* WHY PARTNER */}
                    <div style={{ marginBottom: 60 }}>
                        <h2 style={{
                            fontFamily: "'Playfair Display', serif",
                            fontSize: 36, fontWeight: 700, color: C.text,
                            marginBottom: 32,
                        }}>Why Partner With TableMint?</h2>

                        <div style={{ display: "grid", gap: 20 }}>
                            {[
                                { icon: "📈", title: "Increase Bookings by 40%", desc: "Reach thousands of food lovers actively searching for their next dining experience" },
                                { icon: "❌", title: "Reduce No-Shows by 60%", desc: "Pre-payment system and automated reminders keep customers committed" },
                                { icon: "⚡", title: "Pre-Order = Faster Service", desc: "Food ready when customers arrive. Better experience, faster table turnover" },
                                { icon: "📊", title: "Smart Analytics Dashboard", desc: "Real-time insights on bookings, revenue, peak hours, and customer preferences" },
                                { icon: "💰", title: "Zero Setup Fees", desc: "Only pay a small commission per successful booking. No hidden charges" },
                            ].map(benefit => (
                                <div key={benefit.title} style={{
                                    display: "flex", gap: 20, padding: 24,
                                    background: C.bgCard, borderRadius: 12,
                                    border: `1px solid ${C.border}`,
                                    transition: "all 0.2s ease",
                                }}
                                     onMouseEnter={e => {
                                         e.currentTarget.style.borderColor = C.amber;
                                         e.currentTarget.style.boxShadow = `0 4px 16px ${C.amber}20`;
                                     }}
                                     onMouseLeave={e => {
                                         e.currentTarget.style.borderColor = C.border;
                                         e.currentTarget.style.boxShadow = "none";
                                     }}
                                >
                                    <div style={{
                                        fontSize: 40, width: 64, height: 64,
                                        display: "flex", alignItems: "center", justifyContent: "center",
                                        background: C.amberSoft, borderRadius: 12,
                                        flexShrink: 0,
                                    }}>{benefit.icon}</div>
                                    <div>
                                        <h3 style={{
                                            fontSize: 18, fontWeight: 700, color: C.text,
                                            marginBottom: 8, fontFamily: "'DM Sans', sans-serif",
                                        }}>{benefit.title}</h3>
                                        <p style={{
                                            fontSize: 14, color: C.textMid, lineHeight: 1.6,
                                        }}>{benefit.desc}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* HOW IT WORKS */}
                    <div style={{ marginBottom: 60 }}>
                        <h2 style={{
                            fontFamily: "'Playfair Display', serif",
                            fontSize: 36, fontWeight: 700, color: C.text,
                            marginBottom: 32,
                        }}>How It Works</h2>

                        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24 }}>
                            {[
                                { num: "1", icon: "📝", title: "Sign Up in 5 Minutes", desc: "Quick registration with your restaurant details" },
                                { num: "2", icon: "📋", title: "List Your Restaurant", desc: "Add menu, photos, and set your availability" },
                                { num: "3", icon: "🎉", title: "Start Receiving Bookings", desc: "Customers find you and reserve instantly" },
                            ].map(step => (
                                <div key={step.num} style={{
                                    padding: 24, background: C.bgCard,
                                    borderRadius: 16, border: `2px solid ${C.border}`,
                                    position: "relative",
                                }}>
                                    <div style={{
                                        position: "absolute", top: 16, right: 16,
                                        fontFamily: "'Playfair Display', serif",
                                        fontSize: 64, fontWeight: 900,
                                        color: C.amber + "15", lineHeight: 1,
                                    }}>{step.num}</div>
                                    <div style={{
                                        fontSize: 48, marginBottom: 16,
                                    }}>{step.icon}</div>
                                    <h3 style={{
                                        fontSize: 18, fontWeight: 700, color: C.text,
                                        marginBottom: 12, fontFamily: "'DM Sans', sans-serif",
                                    }}>{step.title}</h3>
                                    <p style={{
                                        fontSize: 14, color: C.textMid, lineHeight: 1.6,
                                    }}>{step.desc}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* FEATURES */}
                    <div style={{ marginBottom: 60 }}>
                        <h2 style={{
                            fontFamily: "'Playfair Display', serif",
                            fontSize: 36, fontWeight: 700, color: C.text,
                            marginBottom: 32,
                        }}>Features That Drive Results</h2>

                        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 20 }}>
                            {[
                                { icon: "📊", title: "Live Dashboard", desc: "Real-time booking status and customer info" },
                                { icon: "🍽️", title: "Pre-Order System", desc: "Customers order food before arriving" },
                                { icon: "💳", title: "Payment Tracking", desc: "Automatic fee collection and reporting" },
                                { icon: "📱", title: "Captain Mobile App", desc: "Staff app to manage orders on the floor" },
                            ].map(feature => (
                                <div key={feature.title} style={{
                                    padding: 24, background: C.bgCard,
                                    borderRadius: 12, border: `1px solid ${C.border}`,
                                }}>
                                    <div style={{
                                        fontSize: 36, marginBottom: 12,
                                    }}>{feature.icon}</div>
                                    <h3 style={{
                                        fontSize: 16, fontWeight: 700, color: C.text,
                                        marginBottom: 8, fontFamily: "'DM Sans', sans-serif",
                                    }}>{feature.title}</h3>
                                    <p style={{
                                        fontSize: 13, color: C.textMid, lineHeight: 1.5,
                                    }}>{feature.desc}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* RIGHT SIDE - STICKY LOGIN BOX (WITH OWN SCROLL) */}
                <div style={{
                    background: C.bgSoft,
                    padding: "60px 40px",
                    borderLeft: `1px solid ${C.border}`,
                    position: "sticky",
                    top: 60,
                    height: "calc(100vh - 60px)",
                    overflowY: "auto",
                }}>
                    <div style={{
                        background: C.bgCard,
                        padding: 32,
                        borderRadius: 20,
                        border: `2px solid ${C.border}`,
                        boxShadow: "0 8px 32px rgba(0,0,0,0.08)",
                    }}>
                        <div style={{
                            textAlign: "center",
                            marginBottom: 28,
                        }}>
                            <div style={{
                                width: 64, height: 64,
                                background: C.amberSoft,
                                borderRadius: "50%",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                fontSize: 32,
                                margin: "0 auto 16px",
                            }}>🍽️</div>
                            <h3 style={{
                                fontFamily: "'Playfair Display', serif",
                                fontSize: 24, fontWeight: 700, color: C.text,
                                marginBottom: 8,
                            }}>Restaurant Portal</h3>
                            <p style={{
                                fontSize: 14, color: C.textMuted,
                            }}>Select your login type</p>
                        </div>

                        {/* OWNER/ADMIN TOGGLE */}
                        <div style={{
                            display: "flex",
                            gap: 8,
                            marginBottom: 24,
                            background: C.bgSoft,
                            padding: 6,
                            borderRadius: 12,
                        }}>
                            <button
                                onClick={() => setLoginType("owner")}
                                style={{
                                    flex: 1,
                                    padding: "12px",
                                    background: loginType === "owner" ? C.amber : "transparent",
                                    border: "none",
                                    borderRadius: 8,
                                    color: loginType === "owner" ? "#fff" : C.textMid,
                                    fontSize: 14,
                                    fontWeight: 700,
                                    cursor: "pointer",
                                    fontFamily: "'DM Sans', sans-serif",
                                    transition: "all 0.2s ease",
                                }}
                            >
                                🔵 Owner
                            </button>
                            <button
                                onClick={() => setLoginType("admin")}
                                style={{
                                    flex: 1,
                                    padding: "12px",
                                    background: loginType === "admin" ? C.green : "transparent",
                                    border: "none",
                                    borderRadius: 8,
                                    color: loginType === "admin" ? "#fff" : C.textMid,
                                    fontSize: 14,
                                    fontWeight: 700,
                                    cursor: "pointer",
                                    fontFamily: "'DM Sans', sans-serif",
                                    transition: "all 0.2s ease",
                                }}
                            >
                                🟢 Admin
                            </button>
                        </div>

                        {/* INFO BOX */}
                        <div style={{
                            padding: 12,
                            background: loginType === "owner" ? C.amberSoft : C.green + "15",
                            borderRadius: 10,
                            marginBottom: 24,
                            border: `1px solid ${loginType === "owner" ? C.amber + "30" : C.green + "30"}`,
                        }}>
                            <div style={{
                                fontSize: 13,
                                color: loginType === "owner" ? C.amber : C.green,
                                fontWeight: 600,
                                lineHeight: 1.5,
                            }}>
                                {loginType === "owner"
                                    ? "🔵 Owner: Manage all restaurants, add admins, view pending verifications"
                                    : "🟢 Admin: Manage assigned restaurant, reservations, and menu"}
                            </div>
                        </div>

                        {/* LOGIN BUTTON */}
                        <button
                            onClick={handleLogin}
                            style={{
                                width: "100%",
                                padding: "16px",
                                background: loginType === "owner" ? C.amber : C.green,
                                border: "none",
                                borderRadius: 12,
                                color: "#fff",
                                fontSize: 16,
                                fontWeight: 700,
                                cursor: "pointer",
                                fontFamily: "'DM Sans', sans-serif",
                                boxShadow: `0 4px 16px ${loginType === "owner" ? C.amber : C.green}40`,
                                transition: "all 0.2s ease",
                                marginBottom: 20,
                            }}
                            onMouseEnter={e => {
                                e.target.style.transform = "translateY(-2px)";
                                e.target.style.boxShadow = `0 6px 20px ${loginType === "owner" ? C.amber : C.green}50`;
                            }}
                            onMouseLeave={e => {
                                e.target.style.transform = "translateY(0)";
                                e.target.style.boxShadow = `0 4px 16px ${loginType === "owner" ? C.amber : C.green}40`;
                            }}
                        >
                            Continue as {loginType === "owner" ? "Owner" : "Admin"} →
                        </button>

                        <div style={{
                            borderTop: `1px solid ${C.border}`,
                            marginTop: 28,
                            paddingTop: 28,
                            textAlign: "center",
                        }}>
                            <p style={{
                                fontSize: 13,
                                color: C.textMuted,
                                marginBottom: 16,
                            }}>New restaurant owner?</p>
                            <button
                                onClick={() => navigate('/owner/login')}
                                style={{
                                    width: "100%",
                                    padding: "14px",
                                    background: "transparent",
                                    border: `2px solid ${C.border}`,
                                    borderRadius: 12,
                                    color: C.text,
                                    fontSize: 15,
                                    fontWeight: 700,
                                    cursor: "pointer",
                                    fontFamily: "'DM Sans', sans-serif",
                                    transition: "all 0.2s ease",
                                }}
                                onMouseEnter={(e) => {
                                    e.target.style.borderColor = C.amber;
                                    e.target.style.color = C.amber;
                                }}
                                onMouseLeave={(e) => {
                                    e.target.style.borderColor = C.border;
                                    e.target.style.color = C.text;
                                }}
                            >
                                🚀 Start Free Trial
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}