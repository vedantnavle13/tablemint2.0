import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';

// Public Pages
import Home from './Home';
import Explore from './Explore';
import RestaurantDetail from './RestaurantDetail';
import ForRestaurants from './ForRestaurants';

// Auth Pages
import LoginPage from './LoginPage';
import OwnerLoginPage from './OwnerLoginPage';

// Dashboards
import Dashboard from './Dashboard';
import OwnerDashboard from './OwnerDashboard';

export default function App() {
    return (
        <AuthProvider>
            <BrowserRouter>
                <Routes>
                    {/* Public Routes */}
                    <Route path="/" element={<Home />} />
                    <Route path="/explore" element={<Explore />} />
                    <Route path="/restaurant/:id" element={<RestaurantDetail />} />
                    <Route path="/for-restaurants" element={<ForRestaurants />} />

                    {/* Customer Login */}
                    <Route path="/login" element={<LoginPage />} />

                    {/* Owner Portal */}
                    <Route path="/owner/login" element={<OwnerLoginPage />} />

                    {/* Admin Login - Same as Owner Login but redirect handled in OwnerLoginPage */}
                    <Route path="/admin/login" element={<OwnerLoginPage />} />

                    {/* Protected Routes - Admin Only */}
                    <Route
                        path="/restaurant-portal/dashboard"
                        element={
                            <ProtectedRoute allowedRoles={['admin']}>
                                <Dashboard />
                            </ProtectedRoute>
                        }
                    />

                    {/* Admin Dashboard - Alias */}
                    <Route
                        path="/admin/dashboard"
                        element={
                            <ProtectedRoute allowedRoles={['admin']}>
                                <Dashboard />
                            </ProtectedRoute>
                        }
                    />

                    {/* Protected Routes - Owner Only */}
                    <Route
                        path="/owner-portal/dashboard"
                        element={
                            <ProtectedRoute allowedRoles={['owner']}>
                                <OwnerDashboard />
                            </ProtectedRoute>
                        }
                    />

                    {/* Owner Dashboard - Alias */}
                    <Route
                        path="/owner/dashboard"
                        element={
                            <ProtectedRoute allowedRoles={['owner']}>
                                <OwnerDashboard />
                            </ProtectedRoute>
                        }
                    />
                </Routes>
            </BrowserRouter>
        </AuthProvider>
    );
}