import { useNavigate } from "react-router-dom";
import { useAuth } from "./context/AuthContext";

const C = {
  bg:        "#FDFAF6",
  bgCard:    "#FFFFFF",
  border:    "#E8E0D0",
  amber:     "#D4883A",
  text:      "#2C2416",
  textMid:   "#6B5B45",
  textMuted: "#A0907A",
};

export default function OwnerDashboard() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const handleLogout = async () => {
    await logout();
    navigate('/for-restaurants');
  };

  return (
    <div style={{ background: C.bg, minHeight: "100vh", fontFamily: "'DM Sans', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,900;1,700&family=DM+Sans:wght@400;500;600;700&display=swap');
        * { box-sizing:border-box; margin:0; padding:0; }
      `}</style>

      {/* NAV */}
      <nav style={{
        background: C.bgCard,
        borderBottom: `1px solid ${C.border}`,
        padding: "0 6%",
        height: 70,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ fontSize: 24 }}>🍽️</span>
            <span style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: 22,
              fontWeight: 700,
              color: C.text,
            }}>
              Table<span style={{ color: C.amber }}>Mint</span>
            </span>
            <span style={{
              fontSize: 13,
              color: C.textMuted,
              fontWeight: 500,
              marginLeft: 8,
            }}>Owner Portal</span>
          </div>
        </div>

        <button
          onClick={handleLogout}
          style={{
            padding: "8px 16px",
            background: "transparent",
            border: `1.5px solid ${C.border}`,
            borderRadius: 10,
            color: C.textMid,
            fontSize: 13,
            fontWeight: 600,
            cursor: "pointer",
            fontFamily: "'DM Sans', sans-serif",
          }}
        >
          Logout
        </button>
      </nav>

      {/* CONTENT */}
      <div style={{
        padding: "60px 6%",
        maxWidth: 1200,
        margin: "0 auto",
        textAlign: "center",
      }}>
        <div style={{
          background: C.bgCard,
          padding: 60,
          borderRadius: 20,
          border: `2px solid ${C.border}`,
          boxShadow: "0 8px 32px rgba(0,0,0,0.06)",
        }}>
          <div style={{
            width: 80,
            height: 80,
            background: C.amber + "20",
            borderRadius: "50%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 40,
            margin: "0 auto 24px",
          }}>🔵</div>

          <h1 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: 36,
            fontWeight: 700,
            color: C.text,
            marginBottom: 16,
          }}>
            Welcome, Owner! 👋
          </h1>

          <p style={{
            fontSize: 16,
            color: C.textMid,
            marginBottom: 8,
            lineHeight: 1.6,
          }}>
            Logged in as: <strong>{user?.email}</strong>
          </p>

          <p style={{
            fontSize: 14,
            color: C.textMuted,
            marginBottom: 32,
          }}>
            Role: <strong>{user?.role}</strong>
          </p>

          <div style={{
            background: C.amber + "15",
            padding: 24,
            borderRadius: 12,
            border: `1px solid ${C.amber}30`,
            marginBottom: 32,
          }}>
            <p style={{
              fontSize: 15,
              color: C.text,
              lineHeight: 1.7,
              marginBottom: 16,
            }}>
              🚧 <strong>Owner Dashboard - Under Construction</strong>
            </p>
            <p style={{
              fontSize: 14,
              color: C.textMid,
              lineHeight: 1.6,
            }}>
              Your teammate's Owner Dashboard design will be integrated here.<br />
              This will include:
            </p>
            <ul style={{
              textAlign: "left",
              marginTop: 16,
              fontSize: 14,
              color: C.textMid,
              lineHeight: 1.8,
              paddingLeft: 20,
            }}>
              <li>Pending restaurant verifications</li>
              <li>Add/manage admin accounts</li>
              <li>View all your restaurants</li>
              <li>Restaurant analytics & stats</li>
            </ul>
          </div>

          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: 16,
          }}>
            <div style={{
              padding: 20,
              background: C.bg,
              borderRadius: 12,
              border: `1px solid ${C.border}`,
            }}>
              <div style={{ fontSize: 28, marginBottom: 8 }}>🏢</div>
              <div style={{ fontSize: 13, color: C.textMuted }}>Your Restaurants</div>
              <div style={{ fontSize: 24, fontWeight: 700, color: C.amber }}>
                {user?.restaurants?.length || 0}
              </div>
            </div>

            <div style={{
              padding: 20,
              background: C.bg,
              borderRadius: 12,
              border: `1px solid ${C.border}`,
            }}>
              <div style={{ fontSize: 28, marginBottom: 8 }}>⏳</div>
              <div style={{ fontSize: 13, color: C.textMuted }}>Pending Verifications</div>
              <div style={{ fontSize: 24, fontWeight: 700, color: C.amber }}>-</div>
            </div>

            <div style={{
              padding: 20,
              background: C.bg,
              borderRadius: 12,
              border: `1px solid ${C.border}`,
            }}>
              <div style={{ fontSize: 28, marginBottom: 8 }}>👥</div>
              <div style={{ fontSize: 13, color: C.textMuted }}>Admins Created</div>
              <div style={{ fontSize: 24, fontWeight: 700, color: C.amber }}>-</div>
            </div>
          </div>

          <button
            onClick={() => navigate('/restaurant-portal/dashboard')}
            style={{
              marginTop: 32,
              padding: "12px 24px",
              background: "transparent",
              border: `2px solid ${C.border}`,
              borderRadius: 10,
              color: C.textMid,
              fontSize: 14,
              fontWeight: 600,
              cursor: "pointer",
              fontFamily: "'DM Sans', sans-serif",
            }}
          >
            View Admin Dashboard (Demo)
          </button>
        </div>
      </div>
    </div>
  );
}
