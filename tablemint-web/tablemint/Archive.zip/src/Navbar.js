import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const C = {
    bg:        "#FDFAF6",
    border:    "#E8E0D0",
    amber:     "#D4883A",
    text:      "#2C2416",
    textMid:   "#6B5B45",
    textMuted: "#A0907A",
};

export default function Navbar() {
    const navigate = useNavigate();
    const location = useLocation();
    const [scrolled, setScrolled] = useState(false);

    // Detect scroll position - triggers at 10px instead of 30px for faster response
    useEffect(() => {
        const handleScroll = () => {
            setScrolled(window.scrollY > 10);  // Changed from 30 to 10
        };

        // Check on mount
        handleScroll();

        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    const navItems = [
        {label: "Home", path: "/"},
        {label: "Explore", path: "/explore"},
        {label: "How It Works", path: "/#how"},
        {label: "For Restaurants", path: "/for-restaurants"}
    ];

    const handleNavClick = (item) => {
        if (item.path.startsWith('#')) {
            navigate('/');
            setTimeout(() => {
                document.querySelector(item.path)?.scrollIntoView({behavior:'smooth'});
            }, 100);
        } else {
            navigate(item.path);
        }
    };

    const isActive = (path) => {
        if (path === "/") {
            return location.pathname === "/";
        }
        return location.pathname === path;
    };

    return (
        <nav style={{
            position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
            height: 60, padding: "0 6%",
            display: "flex", alignItems: "center", justifyContent: "space-between",
            background: scrolled ? "rgba(253,250,246,0.98)" : "transparent",  // Increased opacity from 0.96 to 0.98
            backdropFilter: scrolled ? "blur(12px)" : "none",
            borderBottom: scrolled ? `1px solid ${C.border}` : "none",
            boxShadow: scrolled ? "0 2px 8px rgba(0,0,0,0.04)" : "none",  // Added subtle shadow
            transition: "all 0.25s ease",  // Faster transition from 0.3s to 0.25s
        }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }} onClick={() => navigate('/')}>
                <span style={{ fontSize: 21 }}>🍽️</span>
                <span style={{
                    fontFamily: "'Playfair Display', serif",
                    fontSize: 20, fontWeight: 700, color: C.text,
                }}>Table<span style={{ color: C.amber }}>Mint</span></span>
            </div>

            <div style={{ display: "flex", gap: 28 }}>
                {navItems.map(item => {
                    const active = isActive(item.path);
                    return (
                        <span key={item.label} style={{
                            color: active ? C.amber : C.textMuted,
                            fontSize: 14,
                            fontWeight: active ? 700 : 500,
                            cursor: "pointer",
                            transition: "color 0.2s ease",
                        }}
                              onClick={() => handleNavClick(item)}
                              onMouseEnter={e => e.target.style.color = C.amber}
                              onMouseLeave={e => e.target.style.color = active ? C.amber : C.textMuted}
                        >{item.label}</span>
                    );
                })}
            </div>

            <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <button style={{
                    background: "transparent", border: "none",
                    color: C.textMid, fontSize: 14, fontWeight: 500,
                    cursor: "pointer", padding: "7px 14px",
                    fontFamily: "'DM Sans', sans-serif",
                    transition: "color 0.2s ease",
                }}
                        onMouseEnter={e => e.target.style.color = C.text}
                        onMouseLeave={e => e.target.style.color = C.textMid}
                >Sign In</button>
                <button onClick={() => navigate('/explore')} style={{
                    background: C.amber, border: "none",
                    color: "#fff", fontSize: 14, fontWeight: 600,
                    cursor: "pointer", padding: "8px 20px", borderRadius: 10,
                    fontFamily: "'DM Sans', sans-serif",
                    transition: "all 0.2s ease",
                }}
                        onMouseEnter={e => {
                            e.target.style.transform = "translateY(-1px)";
                            e.target.style.boxShadow = "0 4px 12px rgba(212,136,58,0.4)";
                        }}
                        onMouseLeave={e => {
                            e.target.style.transform = "translateY(0)";
                            e.target.style.boxShadow = "none";
                        }}
                >
                    {location.pathname === '/for-restaurants' ? 'Browse Restaurants' : 'Get Started'}
                </button>
            </div>
        </nav>
    );
}